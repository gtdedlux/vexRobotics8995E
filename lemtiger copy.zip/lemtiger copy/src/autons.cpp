#include "main.h"
#include "lemlib/api.hpp" // IWYU pragma: keep

ASSET(test_txt);

//add lemlib configs

void blueRightSide(){
    chassis.setPose(0, 0, 0);
        rush.extend();

    chassis.moveToPoint(0, 20, 1000);
        chassis.moveToPose(0, 5, 0, 1000, {.forwards = false});
pros::delay(2000);
    rush.retract();

}

void blueLeftSide(){
    // set chassis pose
    chassis.setPose(0, 0, 0);
    // lookahead distance: 15 inches
    // timeout: 2000 ms
    // chassis.follow(path_jerryio_txt, 15, 2000, false);

}

void redRightSide(){
}

void redLeftSide(){
}

// void intakeTask() {
//     setIntake(110);  // Run intake motor indefinitely
//      pros::lcd::print(6, "Intake task started");
//     while (true) {
//         pros::lcd::print(7, "Running...");
//         pros::delay(10);  // Keep the task alive
//     }
// }
int intakeSpeed = 0;

// void intakeTask() {
//     while (true) {
//         setIntake(intakeSpeed);  // Run intake at the current speed
//         pros::delay(10);  // Prevent CPU overload
//     }
// }
void intakeTask() {
    int lastSpeed = 0; // Track last intake speed
    while (true) {
        if (intakeSpeed != lastSpeed) { // Only update if speed changes
            setIntake(intakeSpeed);
            lastSpeed = intakeSpeed;
        }
        pros::delay(10); // Prevent CPU overload
    }
}
void checkIntake(){
    if(intake11W.get_actual_velocity() == 0){
         intakeSpeed = -110;
         pros::delay(200);
         intakeSpeed = 115;
    }
}

// Start the intake task (it runs in the background)
pros::Task intakeController(intakeTask);
void skills(){        

intakeSpeed = 110;
    pros::delay(300);
intakeSpeed = 0;
    pros::delay(200);
    chassis.moveToPoint(0, 14, 4000);  
    chassis.moveToPose(18, 14, -90, 2150, {.forwards = false}, true);
    pros::delay(1500);
    mogoMech.extend();
    chassis.turnToHeading(0, 500);
    intakeSpeed = 115;
    chassis.moveToPoint(24, 40, 2000);
            checkIntake();

    chassis.turnToHeading(40, 200); 
            checkIntake();

        chassis.moveToPose(50, 100, 0, 2000);
        pros::delay(300);
        checkIntake();
        pros::delay(650);
        setArmTarget(-333, 500);
         pros::delay(200);
         intakeSpeed = -110;
         pros::delay(250);
         intakeSpeed = 115;        




    // // wall stake
             chassis.moveToPoint(45, 63, 4000, {.forwards = false}, true);
              chassis.turnToHeading(91, 200);
             chassis.moveToPoint(64, 63, 1000,{.maxSpeed = 70});
               pros::delay(550);
               intakeSpeed = 0; 
             pros::delay(500);
             setArmTarget(-1750, 1500);
            chassis.moveToPoint(65, 63, 1000);
             pros::delay(300);
             intakeSpeed = 110; 
            chassis.moveToPoint(50, 63, 1000, {.forwards = false}, true);
            pros::delay(400);
            setArmTarget(0, 1500);
            chassis.turnToHeading(180, 300);
            chassis.moveToPoint(50, 50, 2000);
            checkIntake();
            chassis.moveToPoint(50, 20, 1000, {.maxSpeed = 80});
            checkIntake();
            chassis.moveToPoint(50, 0, 1000, {.maxSpeed = 80});
            checkIntake();
            chassis.moveToPoint(45, 16, 2000, {.forwards = false}, true);
            //ADD 6TH RING HERE
//     intakeSpeed = 110;
//     chassis.moveToPoint(50, 70, 1000,{.forwards = false}, true);
//     chassis.moveToPoint(50, 50, 2000);
//     checkIntake();
//     chassis.moveToPoint(50, 5, 2000, {.maxSpeed = 80});
//     chassis.moveToPoint(45, 16, 2000, {.forwards = false}, true);
//     //ADD 6TH RING HERE
//    chassis.turnToHeading(-45, 500);
//     chassis.moveToPoint(60, 3, 2000, {.forwards = false, .maxSpeed = 80});
//     pros::delay(500);
//     mogoMech.retract();
//     checkIntake();
//     pros::delay(200);
//     chassis.moveToPoint(50, 16, 2000);
//     chassis.turnToHeading(90, 500);
    //pros::lcd::print(7, "Position %f", chassis.getPose());
//SECOND MOGO
//                     chassis.moveToPoint(-18, 17, 4000, {.forwards = false, .maxSpeed = 80}, true);
//                     pros::delay(2000);
//                     mogoMech.extend();
//    
    
    
    
    pros::delay(1000); // Let the intake run for 5 seconds
    intakeController.remove(); // Stop the intake task
    setIntake(0); // Stop intake motor 

}

