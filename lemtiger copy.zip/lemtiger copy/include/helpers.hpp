#include "main.h"



void setIntake(int intakePower);

void setArm(int armSpeed);

void setArmTarget(float target, int timeout);

void redSort(int intakePower);

void blueSort(int intakePower);
//void monitorIntake(int intakePower);



void mogoSwitch();

void doinkerSwitch();